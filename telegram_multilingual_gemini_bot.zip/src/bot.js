import "dotenv/config";
import { Bot } from "grammy";
import { GoogleGenAI } from "@google/genai";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const CHAT_MODEL = process.env.GEMINI_CHAT_MODEL || "gemini-2.5-flash";
const TRANSCRIPTION_MODEL =
  process.env.GEMINI_TRANSCRIPTION_MODEL || CHAT_MODEL;
const MAX_HISTORY_TURNS = Math.max(
  1,
  Number.parseInt(process.env.MAX_HISTORY_TURNS || "10", 10) || 10
);

if (!TELEGRAM_BOT_TOKEN) {
  console.error("Missing TELEGRAM_BOT_TOKEN. Set it in your hosting environment or .env.");
  process.exit(1);
}
if (!GEMINI_API_KEY) {
  console.error("Missing GEMINI_API_KEY. Set it in your hosting environment or .env.");
  process.exit(1);
}

const bot = new Bot(TELEGRAM_BOT_TOKEN);
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
const histories = new Map();
const busyUsers = new Set();

const SYSTEM_INSTRUCTION = [
  "You are a helpful, friendly AI assistant inside Telegram.",
  "Answer the user's question directly and accurately.",
  "Detect the language the user is using and reply in that same language.",
  "If the user mixes languages, reply naturally in the dominant language.",
  "Always return text only. Never generate or request an audio or voice response.",
  "If you are unsure, say so instead of inventing facts.",
  "Use clear formatting and keep answers appropriately concise."
].join(" ");

function getHistory(userId) {
  if (!histories.has(userId)) histories.set(userId, []);
  return histories.get(userId);
}

function trimHistory(history) {
  const maxMessages = MAX_HISTORY_TURNS * 2;
  if (history.length > maxMessages) {
    history.splice(0, history.length - maxMessages);
  }
}

async function generateText(userId, userText) {
  const history = getHistory(userId);
  history.push({ role: "user", parts: [{ text: userText }] });
  trimHistory(history);

  try {
    const result = await ai.models.generateContent({
      model: CHAT_MODEL,
      contents: history,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7
      }
    });

    const answer = (result.text || "").trim() ||
      "Sorry, I couldn't create a reply. Please try again.";
    history.push({ role: "model", parts: [{ text: answer }] });
    trimHistory(history);
    return answer;
  } catch (error) {
    history.pop();
    console.error("Gemini chat error:", error?.message || error);
    throw new Error(
      "Gemini request failed. Check your API key, model access, quota, and billing/settings."
    );
  }
}

async function transcribeVoice(audioBuffer) {
  // Telegram voice messages are normally OGG/Opus. Audio is sent inline to Gemini;
  // no public file URL is created and no audio response is generated.
  const result = await ai.models.generateContent({
    model: TRANSCRIPTION_MODEL,
    contents: [{
      role: "user",
      parts: [
        { text: "Transcribe the spoken words in this audio accurately. Return only the transcript, in the language spoken. Do not answer the speaker's question and do not add commentary." },
        {
          inlineData: {
            mimeType: "audio/ogg",
            data: audioBuffer.toString("base64")
          }
        }
      ]
    }],
    config: { temperature: 0 }
  });

  return (result.text || "").trim();
}

async function sendLongText(ctx, text) {
  const chunks = [];
  let remaining = String(text || "");
  while (remaining.length > 3900) {
    let splitAt = remaining.lastIndexOf("\n", 3900);
    if (splitAt < 1000) splitAt = 3900;
    chunks.push(remaining.slice(0, splitAt));
    remaining = remaining.slice(splitAt).trimStart();
  }
  if (remaining) chunks.push(remaining);
  for (const chunk of chunks) await ctx.reply(chunk);
}

async function withUserLock(ctx, work) {
  const userId = String(ctx.from.id);
  if (busyUsers.has(userId)) {
    await ctx.reply("একটু অপেক্ষা করুন—আপনার আগের মেসেজটির উত্তর তৈরি হচ্ছে।");
    return;
  }
  busyUsers.add(userId);
  try {
    await work();
  } finally {
    busyUsers.delete(userId);
  }
}

bot.command("start", async (ctx) => {
  await ctx.reply(
    "হ্যালো! আমি Google Gemini-চালিত একটি multilingual AI assistant।\n\n" +
    "• যেকোনো ভাষায় text লিখুন—আমি সেই ভাষাতেই উত্তর দেওয়ার চেষ্টা করব।\n" +
    "• Telegram voice message পাঠালে সেটি text-এ transcribe করে AI-এর উত্তর text হিসেবে দেব।\n" +
    "• আমি কোনো voice/audio reply পাঠাই না।\n\n" +
    "কথা শুরু করতে প্রশ্ন লিখুন বা voice message পাঠান।\n" +
    "/reset — কথোপকথনের history মুছুন\n" +
    "/help — সাহায্য"
  );
});

bot.command("reset", async (ctx) => {
  histories.delete(String(ctx.from.id));
  await ctx.reply("এই কথোপকথনের history মুছে দেওয়া হয়েছে। নতুন করে শুরু করুন।");
});

bot.command("help", async (ctx) => {
  await ctx.reply(
    "ব্যবহার:\n" +
    "1. যেকোনো ভাষায় text পাঠান।\n" +
    "2. Voice message পাঠালে সেটি text-এ রূপান্তর হবে, তারপর AI text উত্তর দেবে।\n" +
    "3. /reset — conversation history reset\n" +
    "4. /help — এই নির্দেশনা\n\n" +
    "নোট: Gemini API quota/usage limits প্রযোজ্য হতে পারে।"
  );
});

bot.on("message:text", async (ctx) => {
  const text = ctx.message.text.trim();
  if (!text || text.startsWith("/")) return;

  await withUserLock(ctx, async () => {
    const status = await ctx.reply("ভাবছি…");
    try {
      const answer = await generateText(String(ctx.from.id), text);
      await ctx.api.deleteMessage(ctx.chat.id, status.message_id).catch(() => {});
      await sendLongText(ctx, answer);
    } catch (error) {
      await ctx.api.deleteMessage(ctx.chat.id, status.message_id).catch(() => {});
      await ctx.reply(
        "দুঃখিত, এখন উত্তর তৈরি করা যায়নি। " +
        (error.message || "কিছুক্ষণ পরে আবার চেষ্টা করুন।")
      );
    }
  });
});

bot.on("message:voice", async (ctx) => {
  await withUserLock(ctx, async () => {
    const status = await ctx.reply("আপনার voice message-টি text-এ রূপান্তর করছি…");
    let tempPath;

    try {
      const file = await ctx.getFile();
      if (!file.file_path) throw new Error("Telegram voice file path পাওয়া যায়নি।");

      // Download through Telegram API using the secret bot token, then delete the temp file.
      const fileUrl = `https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${file.file_path}`;
      const response = await fetch(fileUrl);
      if (!response.ok) throw new Error("Telegram voice file download failed.");

      const audioBuffer = Buffer.from(await response.arrayBuffer());
      // Keep a temporary copy only for the duration of processing.
      tempPath = path.join(os.tmpdir(), `telegram-voice-${ctx.from.id}-${Date.now()}.ogg`);
      fs.writeFileSync(tempPath, audioBuffer);

      const transcript = await transcribeVoice(audioBuffer);
      if (!transcript) throw new Error("Voice message থেকে কোনো text শনাক্ত করা যায়নি।");

      await ctx.api.deleteMessage(ctx.chat.id, status.message_id).catch(() => {});
      await ctx.reply(`আপনি বলেছেন:\n${transcript}`);

      const thinking = await ctx.reply("এখন উত্তর তৈরি করছি…");
      try {
        const answer = await generateText(String(ctx.from.id), transcript);
        await ctx.api.deleteMessage(ctx.chat.id, thinking.message_id).catch(() => {});
        await sendLongText(ctx, answer);
      } catch (error) {
        await ctx.api.deleteMessage(ctx.chat.id, thinking.message_id).catch(() => {});
        throw error;
      }
    } catch (error) {
      await ctx.api.deleteMessage(ctx.chat.id, status.message_id).catch(() => {});
      console.error("Voice processing error:", error?.message || error);
      await ctx.reply(
        "Voice message প্রসেস করা যায়নি। আবার চেষ্টা করুন। " +
        (error.message || "")
      );
    } finally {
      if (tempPath) {
        try { fs.unlinkSync(tempPath); } catch (_) {}
      }
    }
  });
});

bot.catch((error) => {
  console.error("Telegram bot error:", error?.message || error);
});

(async () => {
  console.log("Starting Telegram Gemini multilingual AI bot…");
  await bot.start({
    onStart: (botInfo) => console.log(`Bot running as @${botInfo.username}`)
  });
})().catch((error) => {
  console.error("Failed to start bot:", error?.message || error);
  process.exit(1);
});
