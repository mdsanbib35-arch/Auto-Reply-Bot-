# Telegram Multilingual AI Bot — Google Gemini

## Features
- Google Gemini API for AI text responses
- Tries to answer in the language used by the user
- Telegram voice message → Gemini transcription → Gemini text reply
- The bot does not send voice/audio replies
- `/start`, `/help`, `/reset`
- Short per-user conversation history (stored in memory while the process runs)

## Security first
The string you shared earlier looked like a Telegram bot token. If it was real, treat it as exposed: open BotFather and revoke it, then create a new token. Do not reuse the old token.

Telegram bot token and Gemini API key are different credentials. This project does not hard-code either secret. Keep them in environment variables and never commit `.env` to GitHub.

## 1. Get the two credentials
1. Create/manage your Telegram bot using Telegram's BotFather and copy the new bot token.
2. Create a Gemini API key in Google AI Studio. Check your account's model access, quota, and billing/settings.

## 2. Configure locally
1. Copy `.env.example` to `.env`.
2. Set:
   - `8758680808:AAGGbp3S4LCg9vZdqwPf2IivrOCLge7Bffg` = your new Telegram bot token
   - `AQ.Ab8RN6L3ZyLh4oDhOIfj5ziGCRA167waWpbOq3omTwtywNEeYg` = your Gemini API key
   - Optional `GEMINI_CHAT_MODEL` and `GEMINI_TRANSCRIPTION_MODEL`
3. Install Node.js 20 or newer.
4. Run:

```bash
npm install
npm start
```

Then open Telegram, find your bot, and send `/start`.

On Windows PowerShell, copy `.env.example` and rename the copy to `.env`, then edit it.

## 3. Upload to GitHub
Upload these files/folders:
- `package.json`
- `src/bot.js`
- `.gitignore`
- `.env.example`
- `README_BN.md`

Do **not** upload `.env`, Telegram bot tokens, or Gemini API keys. If a secret was accidentally committed, revoke/rotate it; deleting the line in a later commit may not remove it from Git history.

## 4. Run on a Node.js host
Choose a hosting service that supports a continuously running Node.js process and outbound HTTPS requests.

- Runtime: Node.js 20+
- Install/build command: `npm install`
- Start command: `npm start`
- Add environment variables/secrets in the host dashboard:
  - `TELEGRAM_BOT_TOKEN`
  - `GEMINI_API_KEY`
  - optional model variables

Keep the service running. This project uses Telegram long polling; static website hosting alone cannot run the bot. Avoid running multiple copies of the same polling bot at once.

## Voice workflow
When a voice message arrives, the bot downloads it temporarily from Telegram, asks Gemini to transcribe the OGG audio, sends the transcript as text, then asks Gemini for a text-only answer. The temporary file is deleted after processing. The bot does not synthesize or send audio.

## Notes
- This project uses `@google/genai`, Google's official JavaScript SDK. See the Gemini API documentation: https://ai.google.dev/api/generate-content
- The default model is `gemini-2.5-flash`; model availability can vary by account and may change. If unavailable, set `GEMINI_CHAT_MODEL` and `GEMINI_TRANSCRIPTION_MODEL` to a model currently available in your Gemini API account.
- API quotas and usage charges/limits may apply. Check your Google AI Studio account settings.
- Conversation history is in RAM, so it resets when the bot restarts and is not shared across multiple instances.
- Audio transcription quality depends on the recording, language, and Gemini model support.
